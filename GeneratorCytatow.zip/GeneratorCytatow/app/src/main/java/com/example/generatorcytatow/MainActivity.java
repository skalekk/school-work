package com.example.generatorcytatow;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Random;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    int last = 0;
    Cytat obecnyCytat;
    ArrayList<Cytat> ulubioneCytaty;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button przyciskLosuj = findViewById(R.id.przyciskLosuj);
        przygotujDaneCytatow();
        przyciskLosuj.setOnClickListener(v -> {
            TextView tekstCytat = findViewById(R.id.tekstCytatu);
            TextView tekstAutor = findViewById(R.id.tekstAutora);
            if(!listaCytatow.isEmpty()){
                int pamiec = 0;
                int losowyIndeks = randomGenerator.nextInt(listaCytatow.size());
                do{
                    pamiec = losowyIndeks = randomGenerator.nextInt(listaCytatow.size());
                }while(pamiec == last);
                Cytat losowyCytat = listaCytatow.get(pamiec);
                tekstCytat.setText(losowyCytat.tresc);
                tekstAutor.setText(losowyCytat.autor);
                this.obecnyCytat = losowyCytat;
                last = pamiec;
            }
            Button przyciskUlubione = findViewById(R.id.przyciskUlubione);
            przyciskUlubione.setOnClickListener(b -> {
            });
        });
    }
    private ArrayList<Cytat> listaCytatow = new ArrayList<>();
    private Random randomGenerator = new Random();
    private void przygotujDaneCytatow() {
        // Tworzymy nowe obiekty klasy Cytat, używając naszego konstruktora
        listaCytatow.add(new Cytat("Być albo nie być, oto jest pytanie.", "William Szekspir"));
        listaCytatow.add(new Cytat("Wiem, że nic nie wiem.", "Sokrates"));
        listaCytatow.add(new Cytat("Myślę, więc jestem.", "Kartezjusz"));
        listaCytatow.add(new Cytat("Cierpliwość jest gorzka, lecz jej owoce są słodkie.", "Jean-Jacques Rousseau"));
        listaCytatow.add(new Cytat("Ten, kto ma dlaczego, zniesie prawie każde jak.", "Friedrich Nietzsche"));
    }
}