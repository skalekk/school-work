package com.example.generatorcytatow;

public class Cytat {
    // 1. Pola (atrybuty) - definiują, z czego składa się każdy cytat
    String tresc;
    String autor;

    // 2. Konstruktor - "instrukcja montażu" dla nowego obiektu
    //    Przyjmuje dwa argumenty i przypisuje je do pól.
    public Cytat(String tresc, String autor) {
        this.tresc = tresc;
        this.autor = autor;
    }
}
