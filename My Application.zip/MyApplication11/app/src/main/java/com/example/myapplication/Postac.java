package com.example.myapplication;

import java.util.ArrayList;

public class Postac {
    String imie;
    String plec;
    String rasa;
    ArrayList<String> umiejetnosci;

}
