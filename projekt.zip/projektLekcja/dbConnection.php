<?php
$SERWER = "localhost";
$USER = "root";
$PASSWORD = "";
$DB_SCHEMA = "lotnisko.kk";
$conn = mysqli_connect($SERWER,$USER,$PASSWORD,$DB_SCHEMA);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>