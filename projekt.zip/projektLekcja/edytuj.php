<?php
    require_once("dbConnection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div id = "container"> 
        <form METHOD="POST">
            <input type="String" placeholder="imie" name="imie">
            </br>
            <input type="String" placeholder="nazwisko" name="nazwisko">
            </br>
            <input type="number" placeholder="numer miejsca" name="numer_miejsca">
            </br>
            <button type="submit"> edytuj </button>
        </form>
        <?php
            if(isset( $_POST["imie"]) && isset( $_POST["nazwisko"]) && isset( $_POST["numer_miejsca"]) ){
                $imie = $_POST["imie"];
                $nazwisko = $_POST["nazwisko"];
                $numer_miejsca = $_POST["numer_miejsca"];
                $id = $_GET['id'];
                $sql = "UPDATE bilety SET imie = '$imie', nazwisko = '$nazwisko', numer_miejsca = '$numer_miejsca' WHERE id=$id";
                if(mysqli_query($conn, $sql)){
                    echo("Edytowano pomyślnie");
                    header("Location: index.php");
                }else{
                    echo("edycja nie powiodła się");
                    header("Location: index.php");
                }
            }

        ?>
    </div>
</body>
</html>