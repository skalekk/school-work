<?php
require_once("dbConnection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div id = "container"> 
    <form METHOD="POST">
        <input type="number" placeholder="Numer lotu" name="Numer_lotu">
        <input type="text" placeholder="Miejsce wylotu" name="Miejsce_wylotu">
        <input type="text" placeholder="Miejsce przylotu" name="Miejsce_przylotu">
        <input type="date" placeholder="Data" name="data">
        <input type="time" placeholder="czas" name="czas">
        <input type="String" placeholder="imie" name="imie">
        <input type="String" placeholder="nazwisko" name="nazwisko">
        <input type="number" placeholder="numer miejsca" name="numer_miejsca">
        <button type="submit"> dodaj  </button>
    </form>
    <?php
        if(isset($_POST["Numer_lotu"]) && isset($_POST["Miejsce_wylotu"]) && isset($_POST["Miejsce_przylotu"]) && isset($_POST["data"]) && isset($_POST["czas"]) && isset($_POST["imie"]) &&  isset($_POST["nazwisko"]) &&  isset($_POST["numer_miejsca"])){
            $numerLotu = $_POST["Numer_lotu"];
            $Miejsce_wylotu = $_POST["Miejsce_wylotu"];
            $Miejsce_przylotu = $_POST["Miejsce_przylotu"];
            $date =date_create($_POST["data"]);
            $data = date_format($date,"Y/m/d");
            $time=date_create($_POST["czas"]);
            $godzina = date_format($time,"H:i:s");
            $imie = $_POST["imie"];
            $nazwisko = $_POST["nazwisko"];
            $numer_miejsca = $_POST["numer_miejsca"];
            $sql = "INSERT INTO `bilety`(`numer_lotu`, `wylot`, `przylot`, `data`, `imie`, `nazwisko`, `numer_miejsca`, `godzina`) VALUES ('$numerLotu','$Miejsce_wylotu','$Miejsce_przylotu','$data','$imie','$nazwisko','$numer_miejsca','$godzina')";
            if(mysqli_query($conn, $sql)){
            echo("Dodano pomyślnie"); 
            }else{
                echo("dodawania nie powiodło się"); 
            }
            header("Location:index.php");
        }
    ?>
    </div>
</body>
</html>