<?php require_once("dbConnection.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id = "container"> 
        <h1>Lista biletów: </h1>
        <?php
        $sql = "SELECT * FROM bilety";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) >= 1 ){
            echo("<table>");
            echo("<tr>");
            echo("<th> id </th>");
            echo("<th> numer lotu </th>");
            echo("<th>  wylot </th>");
            echo("<th>  przylot </th>");
            echo("<th> data</th>");
            echo("<th> godzina</th>");
            echo("<th> imie  </th>");
            echo("<th> nazwisko  </th>");
            echo("<th> numer miejsca </th>");
            echo("<th colspan='2'> akcje </th>");
            echo("</tr>");
            while($row = mysqli_fetch_assoc($result))
            {
                echo("<tr>");
                echo("<td>".$row["id"]."</td>");
                echo("<td>".$row["numer_lotu"]."</td>");
                echo("<td>".$row["wylot"]."</td>");
                echo("<td>".$row["przylot"]."</td>");
                echo("<td>".$row["data"]."</td>");
                echo("<td>".$row["godzina"]."</td>");
                echo("<td>".$row["imie"]."</td>");
                echo("<td>".$row["nazwisko"]."</td>");
                echo("<td>".$row["numer_miejsca"]."</td>");
                echo('<td><a href="edytuj.php?id='.$row["id"].'">edytuj</a></td>');
                echo('<td><a href="usun.php?id='.$row["id"].'">usun</a></td>');
                echo("</tr>");
            }
            echo("</table>");
        }else{
            echo("Nie ma jeszcze biletów");
        }



        ?>
        <a href="dodaj.php">
            <button>Dodaj użytkownika</button>
        </a>
    </div>
</body>
</html>