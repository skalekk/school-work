<?php
    require_once("dbConnection.php");
    $sql = "DELETE FROM bilety WHERE id = $_GET[id]";
    if(mysqli_query($conn, $sql)){
        echo("Usunięto użytkownika");
    }else{
        echo("usuwanie nie powiodło się");
    }
    header("Location: index.php");
?>