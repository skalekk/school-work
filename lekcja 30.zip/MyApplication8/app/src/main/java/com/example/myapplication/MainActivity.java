package com.example.myapplication;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.Wydatek;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText poleNazwaWydatku;
    private EditText poleKwotaWydatku;
    private Spinner spinnerKategoria;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        poleNazwaWydatku = findViewById(R.id.poleNazwaWydatku);
        poleKwotaWydatku = findViewById(R.id.poleKwotaWydatku);
        spinnerKategoria = findViewById(R.id.spinnerKategoria);
        Button przyciskZapisz = findViewById(R.id.przyciskZapisz);

        przyciskZapisz.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String nazwa = poleNazwaWydatku.getText().toString().trim();
        String kwotaTekst = poleKwotaWydatku.getText().toString().trim();
        String kategoria = spinnerKategoria.getSelectedItem().toString();

        if (nazwa.isEmpty() || kwotaTekst.isEmpty()) {
            Toast.makeText(this, "Uzupełnij nazwę i kwotę.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String kwotaDoParsowania = kwotaTekst.replace(',', '.');
            double kwota = Double.parseDouble(kwotaDoParsowania);
            Wydatek wydatek = new Wydatek(nazwa, kwota, kategoria);

            Toast.makeText(
                    this,
                    "Zapisano: " + wydatek.getNazwa() + " za " + wydatek.getKwota() + " zł",
                    Toast.LENGTH_SHORT
            ).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Kwota musi być poprawną liczbą.", Toast.LENGTH_SHORT).show();
        }
    }
}